const Page = require('./page');
const homeData = require('../test-data/homePage.json')

class MenuPage extends Page {

    //Bedding
    get beddingRef () { return $('//div[1]/div/div/a') }
    get beddingMenu () { return $('//div[1]/div/div/a/h6') }
    get beddingTitle () { return homeData.menu.bedding.title}
    get beddingUrl () { return homeData.menu.bedding.url }
   
    get heroImgRef (){return $('//div[1]/button/img')} 
    get src () { return $('src') } //Defined 
    get heroImgUrl () {return homeData.menu.heroImg.heroUrl}
    get titleRef () { return $('//h1') } 
    get subTitleRef () { return $('//div[5]/div/div[1]/div[1]/p')} //Defined
    get subTitleCat () { return homeData.subTitle }//Defined
    //Bedding - Value Paks
    get valuePakImage () { return $('//div[2]/div[1]/a[1]/img') }
    get valuePakName () { return $('//div[1]/a[2]/div/div/span') }
    get valuePakUrl () { return homeData.menu.bedding.valuePaks.url}
    get valueProdName () { return homeData.menu.bedding.valuePaks.productName}
    // Bedding -Sheets
    get sheetsImage () { return $('//div[5]/div/div[2]/div[2]/a[1]/img')}
    get sheetsName () {return $ ('//div[2]/a[2]/div/div/span')}
    get sheetsUrl () {return homeData.menu.bedding.sheets.url}
    get sheetsProdName () {return homeData.menu.bedding.sheets.productName}
    // Bedding- Comforters
    get comfortImage () {return $('//div[3]/a[1]/img')}
    get comfortName () {return $('//div[3]/a[2]/div/div/span')}
    get comfortUrl () {return homeData.menu.bedding.comforters.url}
    get comfortProdName () {return homeData.menu.bedding.comforters.productName}
    // Matress Pads
    get padImage () {return $('//div[4]/a[1]/img')}
    get padName () {return $ ('//div[4]/a[2]/div/div/span')}
    get padUrl () {return homeData.menu.bedding.matressPads.url}
    get padProdName () {return homeData.menu.bedding.matressPads.productName}
    // Pillows
    get pillowImage () {return $ ('//div[5]/a[1]/img')}
    get pillowName() {return $ ('//div[5]/a[2]/div/div/span')}
    get pillowUrl () {return homeData.menu.bedding.pillows.url}
    get pillowProdName () {return homeData.menu.bedding.pillows.productName}
    //Blankets and Throws
    get blanketImage () {return $ ('//div[6]/a[1]/img')}
    get blanketName () {return $ ('//div[6]/a[2]/div/div/span')}
    get blanketUrl () {return homeData.menu.bedding.blankets.url}
    get blanketProdName () {return homeData.menu.bedding.blankets.productName}
    // Headboards
    get headImage () {return $ ('//div[7]/a[1]/img')}
    get headName () {return $ ('//div[7]/a[2]/div/div/span')}
    get headUrl () {return homeData.menu.bedding.headboards.url}
    get headProdName () {return homeData.menu.bedding.headboards.productName}
    // BATH
    get bathRef () {return $('//div[2]/div/div/a')}
    get bathMenu () { return $('//div[2]/div/div/a/h6') }
    get bathTitle () { return homeData.menu.bath.title}
    get bathUrl () { return homeData.menu.bath.url }
    // HeroImage Bath
    get heroImgBathRef () {return $('//div[1]/button/img')}
    get heroImgBathUrl () {return homeData.menu.bath.heroUrl}
    get titleBathRef () {return $('//h1')}
    //Towels
    get towelImage () {return $ ('//div[2]/div[1]/a[1]/img')}
    get towelName () {return $ ('//div[1]/a[2]/div/div/span')}
    get towelUrl() {return homeData.menu.bath.towels.url}
    get towelProdName () {return homeData.menu.bath.towels.productName}
    //Shower Paks
    get showerImage () {return $('//div[5]/div/div[2]/div[2]/a[1]/img')}
    get showerName () {return $ ('//div[2]/a[2]/div/div/span')}
    get showerUrl () {return homeData.menu.bath.showerPaks.url}
    get showerProdName () {return homeData.menu.bath.showerPaks.productName}
    //Bath Mats
    get bathMatsImage () {return $('//div[3]/a[1]/img')}
    get bathMatsName () {return $ ('//div[3]/a[2]/div/div/span')}
    get bathMatsUrl () {return homeData.menu.bath.bathMats.url}
    get bathMatsProdName () {return homeData.menu.bath.bathMats.productName}
    //laundry
    get laundryImage () {return $('//div[4]/a[1]/img')}
    get laundryName () {return $ ('//div[4]/a[2]/div/div/span')}
    get laundryUrl () {return homeData.menu.bath.laundry.url}
    get laundryProdName () {return homeData.menu.bath.laundry.productName}
    // DECOR
    get decorRef () { return $('//div[3]/div/div/a')}
    get decorMenu () { return $ ('//div[3]/div/div/a/h6')}
    get decorTitle () {return homeData.menu.decor.title}
    get decorUrl () {return homeData.menu.decor.url}
    // HeroImage Decor
    get heroImgDecorRef () {return $ ('//div[1]/button/img')}
    get heroImgDecorUrl () {return homeData.menu.decor.url}
    get titleDecorRef () {return $('//h1')}
    // Rugs
    get rugImage () {return $('//div[2]/div[1]/a[1]/img')}
    get rugName () {return $ ('//div[1]/a[2]/div/div/span')}
    get rugUrl() {return homeData.menu.decor.rugs.url}
    get rugProdName () {return homeData.menu.decor.rugs.productName}
    // Storage
    get storageImage () {return $('//div[5]/div/div[2]/div[2]/a[1]/img')}
    get storageName () {return $ ('//div[2]/a[2]/div/div/span')}
    get storageUrl () {return homeData.menu.decor.storage.url}
    get storageProdName () {return homeData.menu.decor.storage.productName}
    // Organization
    get organizeImage () {return $ ('//div[3]/a[1]/img')}
    get organizeName () {return $ ('//div[3]/a[2]/div/div/span')}
    get organizeUrl() {return homeData.menu.decor.organization.url}
    get organizeProdName () {return homeData.menu.decor.organization.productName}
    //Housewares
    get houseImage () {return $('//div[4]/a[1]/img')}
    get houseName () {return $('//div[4]/a[2]/div/div/span')}
    get houseUrl () {return homeData.menu.decor.housewares.url}
    get houseProdName () {return homeData.menu.decor.housewares.productName}
    //Lighting
    get lightImage () {return $('//div[5]/a[1]/img')}
    get lightName () {return $ ('//div[5]/a[2]/div/div/span')}
    get lightUrl () {return homeData.menu.decor.lighting.url}
    get lightProdName () {return homeData.menu.decor.lighting.productName}
    //Frames
    get frameImage () {return $ ('//div[6]/a[1]/img')}
    get frameName () {return $ ('//div[6]/a[2]/div/div/span')}
    get frameUrl () {return homeData.menu.decor.frames.url}
    get frameProdName () {return homeData.menu.decor.frames.productName}
    //Mirrors
    get mirrorImage () {return $('//div[7]/a[1]/img')}
    get mirrorName () {return $ ('//div[7]/a[2]/div/div/span')}
    get mirrorUrl () {return homeData.menu.decor.mirrors.url}
    get mirrorProdName () {return homeData.menu.decor.mirrors.productName}
    //Wall Art
    get wallImage () {return $ ('//div[8]/a[1]/img')}
    get wallName () {return $ ('//div[8]/a[2]/div/div/span')}
    get wallUrl () {return homeData.menu.decor.wallart.url}
    get wallProdName () {return homeData.menu.decor.wallart.productName}
    //APARTMENTS
    get apartmentsRef () {return $ ('//div[4]/div/div/a')}
    get apartmentsMenu () {return $ ('//div[4]/div/div/a/h6')}
    get apartmentsTitle () {return homeData.menu.apartments.title}
    get apartmentsUrl () {return homeData.menu.apartments.url}
    
    // HeroImage Apartments
    get heroImgApartRef () {return $('//div[1]/button/img')}
    get heroImgApartUrl () {return homeData.menu.apartments.heroUrl}
    get titleApartRef () {return $('//h1')}

    //Bedroom
    get bedPakImage () {return $ ('//div[2]/div[1]/a[1]/img')}
    get bedPakName () {return $ ('//div[1]/a[2]/div/div/span')}
    get bedPakUrl () {return homeData.menu.apartments.bedroom.url}
    get bedPakProdName () {return homeData.menu.apartments.bedroom.productName}

    //Bathroom
    get bathroomImage () {return $ ('//div[5]/div/div[2]/div[2]/a[1]/img')}
    get bathroomName () {return $ ('//div[2]/a[2]/div/div/span')}
    get bathroomUrl () {return homeData.menu.apartments.bathroom.url}
    get bathroomProdName () {return homeData.menu.apartments.bathroom.productName}

    //Decor
    get decorImage () {return $ ('//div[3]/a[1]/img')}
    get decorName () {return $ ('//div[3]/a[2]/div/div/span')}
    get decorUrl () {return homeData.menu.apartments.decor.url}
    get decorProdName () {return homeData.menu.apartments.decor.productName}

    //Rugs
    get rugsImage () {return $ ('//div[4]/a[1]/img')}
    get rugsName () {return $ ('//div[4]/a[2]/div/div/span')}
    get rugsUrl () {return homeData.menu.apartments.rugs.url}
    get rugsProdName () {return homeData.menu.apartments.rugs.productName}

    //Kitchen
    get KitchenImage () {return $ ('//div[5]/a[1]/img')}
    get KitchenName () {return $ ('//div[5]/a[2]/div/div/span')}
    get kitchenUrl () {return homeData.menu.apartments.Kitchen.url}
    get kitchenProdName () {return homeData.menu.apartments.kitchen.productName}

    //Organization & Accesories
    get accessImage () {return $ ('//div[6]/a[1]/img')}
    get accessName () {return $ ('//div[6]/a[2]/div/div/span')}
    get accessUrl () {return homeData.menu.apartments.access.url}
    get accessProdName () {return homeData.menu.apartments.access.productName}

    //Wellness
    get wellnessRef () {return $ ('//div[5]/div/div/a')}
    get wellnessM () {return $ ('//div[5]/div/div/a/h6')}

    //GIFTS AND CARE PACKAGES
    get carePackageRef () {return $ ('//div[6]/div/div/a')}
    get carePackageMenu () {return $ ('//div[6]/div/div/a/h6')}
    get carePackageTitle () {return homeData.menu.carePackage.title}
    get carePackageUrl () {return homeData.menu.carePackage.url}

    // HeroImage Gifts and carepackages
    get heroImgCareRef () {return $ ('//div[1]/button/img')}
    get heroImgCareUrl () {return homeData.menu.carePackage.heroUrl}
    get TitleCareRef () {return $ ('//h1')}

    // Care Package Plans
    get carePkgPlanImage () {return $ ('//div[2]/div[1]/a[1]/img')}
    get carePkgPlanName () {return $ ('//div[1]/a[2]/div/div/span')}
    get carePkgPlanUrl () {return homeData.menu.carePackage.carePkgPlan.url}
    get carePkgPlanProdName () {return homeData.menu.carePackage.carePkgPlan.productName}
    //Healthy
    get healthImage () {return $('//div[5]/div/div[2]/div[2]/a[1]/img')}
    get healthName () {return $ ('//div[2]/a[2]/div/div/span')}
    get healthUrl () {return homeData.menu.carePackage.health.url }
    get healthProdName (){return homeData.menu.carePackage.health.productName}
    // Birthday
    get birthdayImage () {return $ ('//div[3]/a[1]/img')}
    get birthdayName () {return $ ('//div[3]/a[2]/div/div/span')}
    get birthdayUrl () {return homeData.menu.carePackage.birthday.url}
    get birthdayProdName() {return homeData.menu.carePackage.birthday.productName}
    // Gourmet
    get gourmetImage () {return $ ('//div[4]/a[1]/img')}
    get gourmetName () {return $ ('//div[4]/a[2]/div/div/span')}
    get gourmetUrl () {return homeData.menu.carePackage.gourmet.url}
    get gourmetProdName () {return homeData.menu.carePackage.gourmet.productName}
    // GRADUATION
    get graduationRef () {return $ ('//div[7]/div/div/a')}
    get graduationMenu () {return $ ('//div[7]/div/div/a/h6')}
    get graduationTitle () {return homeData.menu.graduation.title}
    get graduationUrl () {return homeData.menu.graduation.url}
    // HeroImage Graduation
    get heroImgGradRef () {return $ ('//div[1]/button/img')}
    get heroImgGradUrl () {return homeData.menu.graduation.heroUrl}
    get titleGradRef () {return $ ('//h1')}
    // Diploma Frames
    get diplomaImage () {return $('//div[2]/div[1]/a[1]/img')}
    get diplomaName () {return $ ('//div[1]/a[2]/div/div/span')}
    get diplomaUrl () {return homeData.menu.graduation.diploma.url}
    get diplomaProdName () {return homegiftData.menu.graduation.diploma.productName}
    //Commemorative Gifts
    get giftImage () {return $('//div[5]/div/div[2]/div[2]/a[1]/img')}
    get giftName () {return $ ('//div[2]/a[2]/div/div/span')}
    get giftUrl () {return homeData.menu.graduation.gift.url}
    get giftProdName () {return homeData.menu.graduation.gift.productName}
    //Tassel Toppers
    get tasselImage () {return $('//div[3]/a[1]/img')}
    get tasselName () {return $('//div[3]/a[2]/div/div/span')}
    get tasselUrl () {return homeData.menu.graduation.tassel.url}
    get tasselProdName () {return homeData.menu.graduation.tassel.productName}
    //ON SALE
    get onSaleRef () {return $ ('//div[8]/div/div/a')}
    get onSaleMenu () {return $ ('//div[8]/div/div/a/h6')}
    get onSaleTitle () {return homeData.menu.onSale.title}
    get onSaleUrl () {return homeData.menu.onSale.url}
    //HeroImage On Sale
    get heroImgOnSaleRef () {return $ ('//div[1]/button/img')}
    get heroImgOnSaleUrl () {return homeData.menu.onSale.heroUrl}
    get TitleOnSaleRef () {return $ ('//h1')}
    //Bedding
    get bedImage () {return $('//div[2]/div[1]/a[1]/img')}
    get bedName () {return $ ('//div[1]/a[2]/div/div/span')}
    get beddingOnSaleUrl () {return homeData.menu.onSale.beddingOnSale.url}
    get bedProdName () {return homeData.menu.onSale.beddingOnSale.productName}
    //Bath
    get bathImage () {return $('//div[5]/div/div[2]/div[2]/a[1]/img')}
    get bathName () {return $ ('//div[2]/a[2]/div/div/span')}
    get bathOnSaleUrl () {return homeData.menu.onSale.bathOnSale.url}
    get bathProdName () {return homeData.menu.onSale.bathOnSale.productName}
    //Decor
    get decImage () {return $ ('//div[3]/a[1]/img')}
    get decName () {return $ ('//div[3]/a[2]/div/div/span')}
    get decorOnSaleUrl () {return homeData.menu.onSale.decorOnSale.url}
    get decProdName () {return homeData.menu.onSale.decorOnSale.productName}


































    //METHODS
    beddingMenuOption (){
        //1. MENU Y CLICK BEDDING
        expect(this.beddingMenu).toHaveText(this.beddingTitle)
        this.beddingRef.click()
        expect(browser).toHaveUrl(this.beddingUrl)
    }
    heroImg () {
        //2. HERO IMAGE, TITLE Y SUBTITLE BEDDING
        expect(this.heroImgRef).toHaveAttr(this.src, this.heroImgUrl)
        expect(this.titleRef).toHaveText(this.beddingTitle)
        expect(this.subTitleRef).toHaveText(this.subTitleCat)
    }
    valuePaks () {
        expect(this.valuePakImage).toHaveAttr(this.src, this.valuePakUrl)
        expect(this.valuePakName).toHaveText(this.valueProdName)
    }
    sheets () {
        expect(this.sheetsImage).toHaveAttr(this.src,this.sheetsUrl)
        expect(this.sheetsName).toHaveText(this.sheetsProdName)
    }
    comforters () {
        expect(this.comfortImage).toHaveAttr(this.src,this.comfortUrl)
        expect(this.comfortName).toHaveText(this.comfortProdName)
    }
    matressPads(){
        expect(this.padImage).toHaveAttr(this.src,this.padUrl)
        expect(this.padName).toHaveText(this.padProdName)
    }
    pillows(){
        expect(this.pillowImage).toHaveAttr(this.src,this.pillowUrl)
        expect(this.pillowName).toHaveText(this.pillowProdName)
    }
    blankets () {
        expect(this.blanketImage).toHaveAttr(this.src,this.blanketUrl)
        expect(this.blanketName).toHaveText(this.blanketProdName)
    }
    headboards () {
        expect(this.headImage).toHaveAttr(this.src,this.headUrl)
        expect(this.headName).toHaveText(this.blanketProdName)
    }
    bathMenuOption (){
        //1. MENU Y CLICK BATH
        expect(this.bathMenu).toHaveText(this.bathTitle)
        this.bathRef.click()
        expect(browser).toHaveUrl(this.bathUrl)
    }
    heroImgBath () {
        //2. HERO IMAGE, TITLE Y SUBTITLE BATH
        expect(this.heroImgBathRef).toHaveAttr(this.src, this.heroImgBathUrl)
        expect(this.titleBathRef).toHaveText(this.bathTitle)
        expect(this.subTitleRef).toHaveText(this.subTitleCat)
    }
    towels() {
        expect(this.towelImage).toHaveAttr(this.src,this.towelUrl)
        expect(this.towelName).toHaveText(this.towelProdName)
    }
    showerPaks() {
        expect(this.showerImage).toHaveAttr(this.src,this.showerUrl)
        expect(this.showerName).toHaveText(this.src,this.showerProdName)
    }
    bathMats () {
        expect(this.bathMatsImage).toHaveAttr(this.src,this.bathMatsUrl)
        expect(this.bathMatsName).toHaveText(this.bathMatsProdName)
    }
    laundry () {
        expect(this.laundryImage).toHaveAttr(this.laundryUrl)
        expect(this.laundryName).toHaveText(this.laundryProdName)
        
    }
    decorMenuOption () {
        //1. MENU Y CLICK DECOR
        expect(this.decorMenu).toHaveText(this.decorTitle)
        this.decorRef.click()
        expect(browser).toHaveUrl(this.decorUrl)
    }
    heroImgDecor () {
        //2. HERO IMAGE, TITLE Y SUBTITLE BATH
        expect(this.heroImgDecorRef).toHaveAttr(this.src, this.heroImgDecorUrl)
        expect(this.titleRef).toHaveText(this.decorTitle)
        expect(this.subTitleRef).toHaveText(this.subTitleCat)
    }
    rugs () {
        expect(this.rugImage).toHaveAttr(this.rugUrl)
        expect(this.rugName).toHaveText(this.rugProdName)
    }
    storage () {
        expect(this.storageImage).toHaveAttr(this.storageUrl)
        expect(this.storageName).toHaveText(this.storageProdName)
    }
    organization () {
        expect(this.organizeImage).toHaveAttr(this.organizeUrl)
        expect(this.organizeName).toHaveText(this.organizeProdName)

    }
    housewares () {
        expect(this.houseImage).toHaveAttr(this.houseUrl)
        expect(this.houseName).toHaveText(this.houseProdName)       
    }
    lighting () {
        expect(this.lightImage).toHaveAttr(this.lightUrl)
        expect(this.lightName).toHaveText(this.lightProdName)
    }    
    frames () {
        expect(this.frameImage).toHaveAttr(this.frameUrl)
        expect(this.frameName).toHaveText(this.frameProdName)
    }
    mirrors () {
        expect(this.mirrorImage).toHaveAttr(this.mirrorUrl)
        expect(this.mirrorName).toHaveText(this.mirrorProdName)
    }
    wallart () {
        expect(this.wallImage).toHaveAttr(this.wallUrl)
        expect(this.wallName).toHaveText(this.wallProdName)
    }
    apartmentsMenuOption() {
        //1. MENU Y CLICK APARTMENTS
        expect(this.apartmentsMenu).toHaveText(this.apartmentsTitle)
        this.apartmentsRef.click()
        expect(browser).toHaveUrl(this.decorUrl)
    }
    heroImgapartments () {
        //2. HERO IMAGE, TITLE Y SUBTITLE APARTMENTS
        expect(this.heroImgApartRef).toHaveAttr(this.src, this.heroImgApartUrl)
        expect(this.titleRef).toHaveText(this.apartmentsTitle)
        expect(this.subTitleRef).toHaveText(this.subTitleCat)
    }
    bedroom () {
        expect(this.bedPakImage).toHaveAttr(this.bedPakUrl)
        expect(this.bedPakName).toHaveText(this.bedPakProdName)

    }
    bathroom () {
        expect(this.bathroomImage).toHaveAttr(this.bathroomUrl)
        expect(this.bathroomName).toHaveText(this.bathroomProdName)
    }
    decor () {
        expect(this.decorImage).toHaveAttr(this.decorUrl)
        expect(this.decorName).toHaveText(this.decorProdName)
    }
    rugs () {
        expect(this.rugsImage).toHaveAttr(this.rugsUrl)
        expect(this.rugsName).toHaveText(this.rugsProdName)
    }
    Kitchen () {
        expect(this.KitchenImage).toHaveAttr(this.kitchenUrl)
        expect(this.KitchenName).toHaveText(this.kitchenProdName)
    }
    organization () {
        expect(this.organizeImage).toHaveAttr(this.organizeUrl)
        expect(this.organizeName).toHaveText(this.organizeProdName)
    }
    wellnessMenuOption () {

    }
    carepackageMenuOption () {
        //1. MENU Y CLICK CAREPACKAGES
        expect(this.carepackageMenu).toHaveText(this.carepackageTitle)
        this.carepackageRef.click()
        expect(browser).toHaveUrl(this.carepackageUrl)
    }
    heroImgCarePackage () {
        //2. HERO IMAGE, TITLE Y SUBTITLE GIFTS AND CARE PACKAGES
        expect(this.heroImgCareRef).toHaveAttr(this.src, this.heroImgCareUrl)
        expect(this.TitleCareRef).toHaveText(this.carePackageTitle)
        expect(this.subTitleRef).toHaveText(this.subTitleCat)
    }
    carePackagePlans () {
        expect(this.carePkgPlanImage).toHaveAttr(this.carePkgPlanUrl)
        expect(this.carePkgPlanName).toHaveText(this.carePkgPlanProdName)
    }
    Healthy () {
        expect(this.healthImage).toHaveAttr(this.healthUrl)
        expect(this.healthName).toHaveText(this.healthProdName)
    }
    birthday () {
        expect(this.birthdayImage).toHaveAttr(this.birthdayUrl)
        expect(this.birthdayName).toHaveText(this.birthdayProdName)
    }
    gourmet () {
        expect(this.gourmetImage).toHaveAttr(this.gourmetUrl)
        expect(this.gourmetName).toHaveText(this.gourmetProdName)     
    }
    graduationMenuOption () {
        //1. MENU Y CLICK GRADUATION
        expect(this.graduationMenu).toHaveText(this.graduationTitle)
        this.graduationRef.click()
        expect(browser).toHaveUrl(this.graduationUrl)     

    }
    heroImgGraduation () {
        //2. HERO IMAGE, TITLE Y SUBTITLE GIFTS AND CARE PACKAGES
        expect(this.heroImgGradRef).toHaveAttr(this.src, this.heroImgGradUrl)
        expect(this.TitleGradRef).toHaveText(this.graduationTitle)
        expect(this.subTitleRef).toHaveText(this.subTitleCat)
    }
    diplomaFrames () {
        expect(this.diplomaImage).toHaveAttr(this.diplomaUrl)
        expect(this.diplomaName).toHaveText(this.diplomaProdName)
    }
    commemorativeGifts () {
        expect(this.giftImage).toHaveAttr(this.giftUrl)
        expect(this.giftName).toHaveText(this.giftProdName)

    }
    tasselToppers () {
        expect(this.tasselImage).toHaveAttr(this.tasselUrl)
        expect(this.tasselName).toHaveText(this.tasselProdName)
    }
    onSaleMenuOption () {
          //1. MENU Y CLICK On SALE
        expect(this.onSaleMenu).toHaveText(this.onSaleTitle)
        this.onSaleRef.click()
        expect(browser).toHaveUrl(this.onSaleUrl)                
    }
    heroImgOnSale () {
        //2. HERO IMAGE, TITLE Y SUBTITLE ON SALE
        expect(this.heroImgOnSaleRef).toHaveAttr(this.src,this.heroImgOnSaleUrl)
        expect(this.TitleOnSaleRef).toHaveText(this.onSaleTitle)
        expect(this.subTitleRef).toHaveText(this.subTitleCat)
    }
    beddingOnSale () {
        expect(this.bedImage).toHaveAttr(this.beddingOnSaleUrl)
        expect(this.bedName).toHaveText(this.bedProdName)
    }
    bathOnSale () {
        expect(this.bathImage).toHaveAttr(this.bathOnSaleUrl)
        expect(this.bathName).toHaveText(this.bathProdName)
    }
    decorOnSale () {
        expect(this.decImage).toHaveAttr(this.decorOnSaleUrl)
        expect(this.decName).toHaveText(this.decProdName)
    }





    

}

module.exports = new MenuPage()