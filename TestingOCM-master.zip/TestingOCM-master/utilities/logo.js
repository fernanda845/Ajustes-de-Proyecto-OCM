
function backHomePage(){
    let clickLogo = $("//*[@id='__next']/div/main/div/div[1]/div/div[1]/a/img")
    clickOnLogo.click()
}

